#ifndef red_line_layer_update_callback_h
#define red_line_layer_update_callback_h

void red_line_layer_update_callback(Layer *RedLineLayer, GContext* ctx);

#endif